



import fetch from 'node-fetch'


const API_URL = "http://localhost:3000/api/create-checkout-session"


// Simulated cart with the same variant

const cartItem = { 
    orderI: "68b2e87cefb2583458fbb651",
    cartItems: [
        {
            variantId: "688f223987c36326be18ecbb",
            quantity: 1
        },
    ],
}

async function runTest() {

    const requests = Array.from({ length: 5 }, () => 
        fetch(API_URL, {
            method: 'POST',
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify(cartItem)
        })
          .then((res) => res.json())
          .catch((err) => ({ error: err.message }))
    )

    const results = await Promise.all(requests)
    console.log("=== Concurrency Test Results ===")
    results.forEach((r, i) => 
        console.log(`Request ${i + 1}: `, r.error ? r.error : r.url )
    )
}


runTest()