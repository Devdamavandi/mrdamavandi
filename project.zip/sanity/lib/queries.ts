import { groq } from "next-sanity";

export const productBySlugQuery = groq`*[_type == "productContent" && slug.current == $slug][0]{
    name,
    "slug": slug.current,
    "images": images[]{asset->{url}},
    whatsInTheBox,
    tags,
    brand,
    specs,
    richDescription,
    seo
}`
