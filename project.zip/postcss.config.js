


module.exports = {
  plugins: {
    '@tailwindcss/postcss': {
      tailwindConfig: './tailwind.config.ts'
    },
    autoprefixer: {},
  },
}