
export const runtime = 'nodejs'

import { auth } from '@/auth'
import { prisma } from '@/lib/db'
import { NextResponse } from 'next/server'
import Stripe from 'stripe'
import { createHash } from 'crypto'



const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)


// eslint-disable-next-line @typescript-eslint/no-unused-vars
interface CheckoutItem {
    name?: string | null;
    productId?: string | null;
    variantId?: string | null;
    price?: number | null;
    quantity?: number | null;
    stripePriceId?: string | null
}


export async function POST(req: Request) {

    try {
        const session = await auth()

    if (!session?.user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })

    const { items, billingAddress, shippingAddress } = await req.json()
    if (!Array.isArray(items) || items.length === 0) return NextResponse.json({ error: 'Invalid items' } , { status: 400 })



    // 1) Server-side normalize and fetch variant data (authoritative)
    const normalized = await Promise.all(
        items.map(async (i) => {
            // If client provided  stripePriceId, validate & fetch variant by stripePriceId
            if (i.stripePriceId) {
                const variant = await prisma.variant.findUnique({
                    where: { stripePriceId: String(i.stripePriceId) },
                    select: { id: true, name: true, stock: true, price: true, productId: true, stripePriceId: true }
                })
                if (!variant) throw new Error(`Invalid stripeProceId: ${i.stripePriceId}`)
                return {
                    variantId: variant?.id,
                    productId: variant?.productId,
                    price: variant?.price,
                    stripePriceId: variant.stripePriceId,
                    name: variant.name ?? 'Item',
                    quantity: Number(i.quantity ?? 1)
                }
            }

            // IF client couldnt provide stripePriceId for whatever reason(like COD payment or Mongodb Server failure), fetch variantId
            if (i.variantId) {
                const variant = await prisma.variant.findUnique({
                    where: { id: String(i.variantId) },
                    select: { id: true, name: true, stock: true, price: true, productId: true, stripePriceId: true }
                })
                if (!variant) throw new Error(`Invalid variantId: ${i.variantId}`)
                return {
                    variantId: variant.id,
                    productId: variant.productId,
                    price: variant.price,
                    name: variant.name ?? '',
                    stripePriceId: variant.stripePriceId ?? null,
                    quantity: Number(i.quantity ?? 1)
                }
            }


            // fallback (least preferred): use client-provided productId/price
            return {
                variantId: i.variantId ?? null,
                productId: i.productId ?? null,
                price: Number(i.price ?? 0),
                stripePriceId: null,
                name: i.name ?? "Item",
                quantity: Number(i.quantity ?? 1)
            }
        })
    )


    // 2) Compute deterministic idempotency key from user + normalized items + addresses
    const idempotencySource = JSON.stringify({
        userId: session.user.id,
        items: normalized.map((item) => ({ variantId: item.variantId, productId: item.productId, qty: item.quantity, price: item.price })),
        billingAddress,
        shippingAddress
    })
    const idempotencyKey = createHash("sha256").update(idempotencySource).digest("hex")


    // 3) Try to find existing order with this idempotency orderNumber
    // we use orderNumber as a stable unique marker (orderNumber is unique in your schema)
    const existingOrder = await prisma.order.findUnique({ 
        where: { orderNumber: idempotencyKey },
        include: { items: true }
    })

    if (existingOrder) {
        // If an order exists and already has a stripeSessionID, return it. Otherwise at the end of this code, We Create a Stripe SessionID
        if (existingOrder.stripeSessionID) return NextResponse.json({ sessionId: existingOrder.stripeSessionID })
    }


    // 4. Reserve stock & create a PENDING order atomically (if not exists)
    let createdOrder = existingOrder
    if (!createdOrder) {
        createdOrder = await prisma.$transaction(async (tx) => {
            // Reserve each variant atomically
            for (const item of normalized) {
                if (!item.variantId) continue; // skip decrement - because we cant reserve
                
                const res = await tx.variant.updateMany({
                    where: { id: item.variantId, stock: { gte: item.quantity } },
                    data: { stock: { decrement: item.quantity } }
                })
                if (res.count === 0) throw new Error(`Insufficient stock for variant ${item.variantId}`)
            }

            // Create billing and shipping addresses first
            const billing = await tx.address.create({
                data: {
                    street: billingAddress?.street ?? '',
                    city: billingAddress?.city ?? '',
                    state: billingAddress?.state ?? '',
                    zipCode: billingAddress?.zipCode ?? '',
                    user: { connect: { id: session.user.id } }
                }
            });

            const shipping = await tx.address.create({
                data: {
                    street: shippingAddress?.street ?? '',
                    city: shippingAddress?.city ?? '',
                    state: shippingAddress?.state ?? '',
                    zipCode: shippingAddress?.zipCode ?? '',
                    user: { connect: { id: session.user.id } }
                }
            });

            // Create order in PENDING with orderNumber - idempotencyKey (dedupe marker)
            const order = await tx.order.create({
                data: {
                    userId: session.user.id,
                    orderNumber: idempotencyKey,
                    paymentStatus: "PENDING",
                    paymentMethod: "CREDIT_CARD", // because this file wont be used for COD Payment Method
                    tax: 0,
                    shippingCost: 0,
                    subtotal: normalized.reduce((sum, item) => sum + (item.price ?? 0) * item.quantity, 0),
                    total: normalized.reduce((sum, item) => sum + (item.price ?? 0) * item.quantity, 0),
                    items: {
                        create: normalized.map((item) => ({
                            product: item.productId ? { connect: { id: item.productId } } : { connect: { id: '' } },
                            variantId: item.variantId ?? undefined,
                            quantity: item.quantity,
                            priceAtPurchase: item.price ?? 0
                        }))
                    },
                    billingAddressId: billing.id,
                    shippingAddressId: shipping.id,
                },
                include: { items: true }
            });

            return order
        })
    }
 
    // 5. Build Stripe line_items preferring server-side stripePriceId
    const line_items = normalized.map((item) => {
        if (item.stripePriceId) return { price: item.stripePriceId, quantity: item.quantity }

        // fallback to server price_data using server-sourced price
        return {
            price_data: {
                currency: "usd",
                unit_amount: Math.round(Number(item.price ?? 0) * 100),
                product_data: { name: item.name ?? "Item", metadata: { productId: item.productId ?? "", variantId: item.variantId ?? "" } }
            },
            quantity: item.quantity
        }
    })


    // 6. Create Stripe Checkout session with idempotency key (Stripe-level)
    let checkoutSession: Stripe.Checkout.Session
    try {
         
        checkoutSession = await stripe.checkout.sessions.create(
            {
                payment_method_types: ['card'],
                mode: "payment",
                line_items,
                success_url: `${process.env.NEEXT_PUBLIC_API_BASE_URL}/order/order-success?session_id={CHECKOUT_SESSION_ID}`,
                cancel_url: `${process.env.NEXT_PUBLIC_API_BASE_URL}/order/cancel`,
                metadata: {
                    orderId: createdOrder.id,
                    userId: session.user.id
                }
            },
            { idempotencyKey } // Ensure Stripe deduplicates
        )
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } catch (stripeErr: any) {
        // If stripe session creation fails after the DB reservation, we MUST release reserved stock and cancel order
        console.error('Stripe session create failed: ', stripeErr?.message || stripeErr);

        try {
            // restore stock for createdOrder (if created in DB)
            if (createdOrder && createdOrder.id) {
                // eslint-disable-next-line @typescript-eslint/no-explicit-any
                const toRestore = (createdOrder.items ?? []).filter((item: any) => item.variantId).map((item: any) =>
                    prisma.variant.update({
                        where: { id: item.variantId },
                        data: { stock: { increment: item.quantity } }
                    })
                );

                await prisma.$transaction([
                    ...toRestore,
                    prisma.order.update({
                        where: { id: createdOrder.id },
                        data: { paymentStatus: "FAILED", status: "CANCELLED" }
                    })
                ]);
            }
        } catch (cleanupErr) {
            console.error('Failed to cleanup reservation after stripe error: ', cleanupErr)
        }

        return NextResponse.json({ error: 'Failed to create checkout session (payment provider)' }, { status: 502 })
    }


    // 7. Attach stripeSessionID to order if not present
    if (!createdOrder.stripeSessionID) {
        await prisma.order.update({
            where: { id: createdOrder.id },
            data: { stripeSessionID: checkoutSession.id }
        })
    }


    return NextResponse.json({ sessionId: checkoutSession.id })
    
    } catch (error) {
        console.error("Stripe error: ", error)
        const errorMessage = typeof error === 'object' && error !== null && 'message' in error
            ? (error as { message: string }).message
            : "Failed to create checkout session.";
        return NextResponse.json({ error: errorMessage }, { status: 500 })
    }
    
}