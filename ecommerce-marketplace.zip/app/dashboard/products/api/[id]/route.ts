import {prisma} from "@/lib/db";
import { VariantFormValues } from "@/types/zod";
import { NextResponse } from "next/server";


// GEt single product server code
export async function GET(request: Request, {params} : {params: {id: string}}) {

    try {
        const {id} = await params
        const product = await prisma.product.findUnique({
            where: {id},
            include: {
                category: true,
                variants: true,
                WishlistItem: true,
                ProductShipping: true,
                reviews: true
            }
        })

        if (!product) return NextResponse.json({error: 'Product not Found!'}, {status: 404})

        
        return NextResponse.json(product)
    } catch {
        return NextResponse.json({
            error: 'Failed to fetch this product'
        }, {status: 500})
    }
}


// Update single product server code
export async function PUT(request: Request, {params} : {params: {id: string}}) {

    try {
        const { id } = await params
        const body = await request.json()


      const product = await prisma.product.update({
        where: { id: id },
        data: {
            // Explicitly specify only updatable fields
            name: body.name,
            slug: body.slug,
            description: body.description,
            price: body.price,
            stock: body.stock,
            sku: body.sku,
            images: body.images,
            categoryId: body.categoryId,
            variants: body.variants && {
                 
                upsert: body.variants.map((v: VariantFormValues) => ({
                    where: { id: v.id },
                    update: {
                        name: v.name || '',
                        sku: v.sku || '',
                        price: v.price,
                        stock: v.stock || 0,
                        discount: v.discount || 0,
                        attributes: v.attributes || {},
                        stripePriceId: v.stripePriceId || null,
                        isDraft: false,
                        isDefault: v.isDefault || null
                    },
                    create: {
                        name: v.name || '',
                        sku: v.sku || '',
                        price: v.price || 0,
                        stock: v.stock || 0,
                        discount: v.discount || 0,
                        stripePriceId: v.stripePriceId || null,
                        attributes: v.attributes|| {},
                        isDefault: v.isDefault || null
                    },
                }))
            },
            whatsInTheBox: body.whatsInTheBox,
            hasFreeShipping: body.hasFreeShipping,
            returnGuarantee: body.returnGuarantee,
            ProductShipping: {
                upsert: {
                    update: {
                        shipsIn: body.ProductShipping?.shipsIn || '',
                        shipsFrom: body.ProductShipping?.shipsFrom || '',
                        shipsTo: body.ProductShipping?.shipsTo || '',
                        estimatedTime: body.ProductShipping?.estimatedTime || '',
                        carrier: body.ProductShipping?.carrier || '',
                        trackingNote: body.ProductShipping?.trackingNote || '',
                        cost: body.ProductShipping?.cost || 0
                    },
                    create: {
                        shipsIn: body.ProductShipping?.shipsIn || '',
                        shipsFrom: body.ProductShipping?.shipsFrom || '',
                        shipsTo: body.ProductShipping?.shipsTo || '',
                        estimatedTime: body.ProductShipping?.estimatedTime || '',
                        carrier: body.ProductShipping?.carrier || '',
                        trackingNote: body.ProductShipping?.trackingNote || '',
                        cost: body.ProductShipping?.cost || 0     
                    }
                }
            }
            // Omit createdAt and updatedAt as they're managed by Prisma
        },
        include: {
            variants: true,
            ProductShipping: true
        }
    })


        if (!product) {
            return NextResponse.json(
                {error: 'Failed to update product'}, {status: 400}
            )
        }
        return NextResponse.json(product)
    } catch(error){
        console.error('Failed to update the product: ', error)
        return NextResponse.json({
            error: 'Failed to update the product',
            details: error instanceof Error ? error.message : error
        }, { status: 500 })
    }
}


// Delete single product server code
export async function DELETE(request: Request, {params} : {params: {id: string}}) {

    try {

        const {id} = await params
        
        const product = await prisma.product.delete({
            where: {id}
        })
        return NextResponse.json({message: `Product '${product.name}' Deleted Successfully!`})
    } catch {
        return NextResponse.json({
            error: 'Failed to delete the product'
        }, {status: 500})
    }
}