


/**
 * This API is for Creating a Top Products
 * Array to be used on dashboard main page Top Products
 * Criteria Select Box
 */


import { prisma } from "@/lib/db"
import { NextResponse } from "next/server"
import { Product } from "@prisma/client"


export async function GET(req: Request) {

    try {
       
        const { searchParams } = new URL(req.url)
        const criteria = searchParams.get("criteria")

        let topProducts: Product[] = []
        
        switch (criteria) {
            case 'most-purchased':
                topProducts = await prisma.product.findMany({
                    orderBy: {
                        OrderItem: { _count: 'desc' }
                    },
                    take: 6
                })
                break;
            case 'most-viewed':
                topProducts = await prisma.product.findMany({
                    orderBy: {
                        views: 'desc'
                    },
                    take: 6
                })
                break;
            case 'most-wishlisted':
                topProducts = await prisma.product.findMany({
                    orderBy: {
                        WishlistItem: { _count: 'desc' }
                    },
                    take: 6
                }) 
                break;
            case 'highest-revenue':
                topProducts = await prisma.product.findMany({
                    where: { 
                        OrderItem: {
                            every: { 
                                order: { 
                                    paymentStatus: 'PAID'                                   
                                },
                            },
                        },
                     },
                    orderBy: {
                        revenue: 'desc'
                    },
                    take: 6
                })
                break;
            default: 
                topProducts = []
        }

        
        return NextResponse.json({ topProducts })
    } catch (error) {
        console.error('Failed to fetch Top Products!!', error)
        return NextResponse.json({ error: "Failed to fetch top products" }, { status: 500 })
    }
}