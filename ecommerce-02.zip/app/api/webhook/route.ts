import Stripe from "stripe"
import { NextResponse } from "next/server"
import { prisma } from "@/lib/db"
import { ObjectId } from "bson"



export const runtime = 'nodejs'
export const dynamic = 'force-dynamic'



const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!)

export async function POST(req:Request) {

    const body = await req.text()
    const sig = req.headers.get('stripe-signature')
    
    
    
    if (!sig) {
        return NextResponse.json({ error: "Missing Stripe signature header" }, { status: 400 });
    }
    
    console.log('webhook endpoint called')
    let event: Stripe.Event | undefined
    try {
         event = stripe.webhooks.constructEvent(
        body,
        sig!,
        process.env.STRIPE_WEBHOOK_SECRET!
    )
    } catch (e: unknown) {
        const message = e instanceof Error ? e.message : 'Unknown error';
        console.error("Stripe signature verification failed: ", message)
        return NextResponse.json({ error: `Webhook error: ${message}` }, { status: 400 })        
    }
    
    if (event.type === 'checkout.session.completed') {
        const sess = event.data.object as Stripe.Checkout.Session
        console.log('chekout.session.completed received, session id: ', sess.id)
        
        

        // Retrieve line items
        let line_items
        try {
            line_items = await stripe.checkout.sessions.listLineItems(sess.id, { expand: ['data.price.product'] })
        } catch (err) {
            console.error("Stripe line items fetch failed:", err)
            return NextResponse.json({ error: "Failed to fetch line items" }, { status: 400 })
        }

        const items = line_items.data.map((li) => ({
            productId: li.price?.product?.toString() || '',
            variantId: li.price?.lookup_key || '',
            quantity: li.quantity || 1,
            priceAtPurchase: (li.price?.unit_amount || 0) / 100,
        }))

        
        try {
            // Update existing order instead of creating a new one
            const updatedOrder = await prisma.order.update({
                where: { stripeSessionID: sess.id },
                data: { 
                    paymentStatus: 'PAID',
                    paymentMethod: 'CREDIT_CARD',
                    total: (sess.amount_total ?? 0) / 100,
                },
                include: { items: { select: { productId: true, quantity: true } } },
            })


            console.log('Order updated to PAID: ', updatedOrder.id)


            // Decrement Stock
            if (updatedOrder.items.length > 0) {
                await prisma.$transaction(
                    updatedOrder.items.map((item) => 
                        prisma.product.update({
                            where: { id: item.productId },
                            data: { stock: { decrement: item.quantity } }
                        })
                    )
                )
                console.log('Product stock decremented for order: ', updatedOrder.id)
            } else {
                console.warn('No items found for order, stock not decremented')
            }
        } catch (err) {
            console.error('Order udate failed: ', err)
            return NextResponse.json({ error: 'order update failed' }, { status: 500 })
        }
    }
    
    console.log("🔔 Stripe Webhook triggered:", event.type)
    return NextResponse.json({ received: true })
}
